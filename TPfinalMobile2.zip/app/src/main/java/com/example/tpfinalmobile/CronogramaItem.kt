package com.example.tpfinal_mobile

data class CronogramaItem(
    val dia: String,
    val horario: String,
    val materia: String
)